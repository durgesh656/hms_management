package com.hms.room_management_service.controller;

import com.hms.room_management_service.dto.RoomStatusResponse;
import com.hms.room_management_service.entities.Room;
import com.hms.room_management_service.services.RoomService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")

@Slf4j
@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
public class RoomController {
    private final RoomService roomService;

    @PostMapping("/add")
    public ResponseEntity<?> addRoom(@RequestHeader("X-Role") String role, @Valid @RequestBody Room room) {
        if (!role.equalsIgnoreCase("ADMIN")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Only admin can add rooms.");
        }
        log.info("Admin adding new room: {}", room);
        Room savedRoom = roomService.addRoom(room);
        log.info("Room added successfully: {}", savedRoom);
        return ResponseEntity.ok(savedRoom);
    }

    @GetMapping
    public ResponseEntity<List<Room>> getAllRooms(@RequestHeader("X-Role") String role) {
        log.info("{} requesting to get rooms", role);
        List<Room> rooms = role.equalsIgnoreCase("ADMIN") ?
                roomService.getAllRooms() :
                roomService.getAvailableRooms();
        log.info("Returning {} rooms for role {}", rooms.size(), role);
        return ResponseEntity.ok(rooms);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getRoomById(@RequestHeader("X-Role") String role, @PathVariable Long id) {
        log.info("{} requesting room with ID: {}", role, id);
        return roomService.getRoomById(id)
                .map(room -> {
                    if (!role.equalsIgnoreCase("ADMIN") && !room.isAvailable()) {
                        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied. Room is not available.");
                    }
                    return ResponseEntity.ok(room);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteRoom(@RequestHeader("X-Role") String role, @PathVariable Long id) {
        if (!role.equalsIgnoreCase("ADMIN")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Only admin can delete rooms.");
        }
        log.info("Admin deleting room with ID: {}", id);
        roomService.deleteRoom(id);
        return ResponseEntity.noContent().build();
    }

    // ✅ Called by Booking Service via Feign
    @GetMapping("/available/{roomType}")
    public ResponseEntity<Room> getAvailableRoomByType(
            @PathVariable String roomType,
            @RequestHeader("X-Role") String role) {

        log.info("Fetching available room of type: {} for role: {}", roomType, role);
        return roomService.getAvailableRooms().stream()
                .filter(room -> room.getType().equalsIgnoreCase(roomType) && room.isAvailable())
                .findFirst()
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }


    @GetMapping("/status")
    public ResponseEntity<?> getRoomStatus(@RequestHeader("X-Role") String role) {
        if (!role.equalsIgnoreCase("ADMIN")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Only admin can view room status.");
        }
        RoomStatusResponse status = roomService.getRoomStatus();
        return ResponseEntity.ok(status);
    }

    @PutMapping("/{roomId}/availability")
    public ResponseEntity<String> updateRoomAvailability(
            @RequestHeader("X-Role") String role,
            @PathVariable Long roomId,
            @RequestParam boolean available
    ) {
        roomService.updateRoomAvailability(roomId, available);
        return ResponseEntity.ok("Room availability updated successfully");
    }
}
