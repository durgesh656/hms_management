package com.hms.billing_and_payment_service.feign;


import com.hms.billing_and_payment_service.dto.BookingDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "booking-management-service", path = "/api/bookings")
public interface BookingClient {

    @GetMapping("/{id}")
    BookingDTO getBookingById(@PathVariable("id") Long id);
}