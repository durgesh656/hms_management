package com.hms.registration_service.feign;

import com.hms.registration_service.model.BookingDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "booking-management-service")
public interface BookingClient {
    @PostMapping("/api/bookings")
    BookingDTO createBooking(@RequestBody BookingDTO booking);
}
