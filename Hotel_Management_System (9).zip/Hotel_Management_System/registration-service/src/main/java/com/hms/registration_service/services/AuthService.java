package com.hms.registration_service.services;

import com.hms.registration_service.dto.LoginRequest;
import com.hms.registration_service.dto.RegisterRequest;
import com.hms.registration_service.entities.User;
import com.hms.registration_service.repositories.UserRepository;
import com.hms.registration_service.security.JwtService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public Map<String, Object> register(RegisterRequest request) {
        log.info("Registering user: {}", request.getUsername());

        // Check if username already exists
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            throw new RuntimeException("Username already exists! try with another one");
        }

        // Default role to "user" if not provided
        String role = request.getRole() == null ? "user" : request.getRole().toLowerCase();

        // Allow only one admin
        if ("admin".equals(role)) {
            boolean adminExists = userRepository.findAll().stream()
                    .anyMatch(user -> "admin".equalsIgnoreCase(user.getRole()));
            if (adminExists) {
                throw new RuntimeException("Admin already exists. Only one admin is allowed.");
            }
        }

        // Save the user
        User user = User.builder()
                .fullName(request.getFullName())
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(role)
                .build();

        userRepository.save(user);

        return Map.of(
                "message", "User registered successfully",
                "username", user.getUsername(),
                "role", user.getRole()
        );
    }

    public String login(LoginRequest request) {
        log.info("Login attempt: {}", request.getUsername());

        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        return (jwtService.generateToken(user)); // Return just the token
    }

}
