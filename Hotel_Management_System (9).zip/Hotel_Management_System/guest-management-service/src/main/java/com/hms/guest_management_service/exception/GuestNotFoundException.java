package com.hms.guest_management_service.exception;

public class GuestNotFoundException extends RuntimeException{
    public GuestNotFoundException(String message){
        super(message);
    }
}