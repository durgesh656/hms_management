package com.hms.booking_management_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
