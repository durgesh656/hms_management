package com.hms.booking_management_service.services;

import com.hms.booking_management_service.entities.Booking;
import com.hms.booking_management_service.dto.Room;
import com.hms.booking_management_service.feign.GuestServiceClient;
import com.hms.booking_management_service.feign.RoomServiceClient;
import com.hms.booking_management_service.repositories.BookingRepository;
import com.hms.booking_management_service.dto.GuestRequest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final RoomServiceClient roomServiceClient;
    private final GuestServiceClient guestServiceClient;

    @Override
    public Booking createBooking(Booking booking) {
        log.info("Checking room availability for type: {}", booking.getRoomType());

        Room availableRoom = roomServiceClient.getAvailableRoomByType(booking.getRoomType(), "USER");
        if (availableRoom == null || !Boolean.TRUE.equals(availableRoom.getAvailable())) {
            throw new RuntimeException("No available rooms of type: " + booking.getRoomType());
        }

        booking.setRoomId(availableRoom.getId());

        // Set room price based on type
        double price = switch (booking.getRoomType().toLowerCase()) {
            case "single" -> 2000.0;
            case "deluxe" -> 3000.0;
            case "vip" -> 4000.0;
            default -> throw new RuntimeException("Invalid room type: " + booking.getRoomType());
        };
        booking.setRoomPrice(price);

        // Validate date range
        long days = ChronoUnit.DAYS.between(booking.getCheckInDate(), booking.getCheckOutDate());
        if (days <= 0) {
            throw new RuntimeException("Check-out date must be after check-in date");
        }

        // Calculate total and booking date
        booking.setTotalAmount(price * days);
        booking.setBookingDate(LocalDate.now());

        // Save booking
        Booking savedBooking = bookingRepository.save(booking);
        log.info("Booking saved with ID: {}", savedBooking.getId());

        // Mark room as unavailable
        roomServiceClient.updateRoomAvailability(availableRoom.getId(), false, "USER");

        // ✅ Add guest data to Guest Service (new)
        GuestRequest guestRequest = new GuestRequest(
                //booking.getGuestId(),
                booking.getGuestName(),
                booking.getEmail(),
                booking.getMobile(),
                savedBooking.getRoomId(),
                savedBooking.getCheckInDate(),
                savedBooking.getCheckOutDate(),
                savedBooking.getId()
        );
        guestServiceClient.addGuestInfo(guestRequest);
        log.info("Guest info sent to Guest Service for guestId: {}");

        // ❌ NO PAYMENT HERE

        return savedBooking;
    }


    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    @Override
    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }
}
