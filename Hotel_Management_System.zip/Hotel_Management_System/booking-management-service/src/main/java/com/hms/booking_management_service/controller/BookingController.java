package com.hms.booking_management_service.controller;

import com.hms.booking_management_service.entities.Booking;
import com.hms.booking_management_service.services.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/bookings")
//@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping
    public ResponseEntity<Booking> createBooking(@Valid @RequestBody Booking booking) {
        log.info("Received request to create booking: {}", booking);
        Booking saved = bookingService.createBooking(booking);
        log.info("Booking created successfully with ID: {}", saved.getId());
        return ResponseEntity.ok(saved);
    }

    @GetMapping
    public ResponseEntity<List<Booking>> getAllBookings() {
        log.info("Received request to get all bookings");
        List<Booking> bookings = bookingService.getAllBookings();
        log.info("Returning {} bookings", bookings.size());
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long id) {
        log.info("Received request to get booking with ID: {}", id);
        return bookingService.getBookingById(id)
                .map(booking -> {
                    log.info("Booking found: {}", booking);
                    return ResponseEntity.ok(booking);
                })
                .orElseGet(() -> {
                    log.warn("Booking with ID {} not found", id);
                    return ResponseEntity.notFound().build();
                });

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBooking(@PathVariable Long id) {
        log.info("Received request to delete booking with ID: {}", id);
        bookingService.deleteBooking(id);
        log.info("Booking with ID {} deleted successfully", id);
        return ResponseEntity.noContent().build();
    }
}
