package com.hms.guest_management_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuestManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
