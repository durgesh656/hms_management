package com.hms.registration_service.services;

import com.hms.registration_service.dto.LoginRequest;
import com.hms.registration_service.dto.RegisterRequest;
import com.hms.registration_service.entities.User;
import com.hms.registration_service.repositories.UserRepository;
import com.hms.registration_service.security.JwtService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public String register(RegisterRequest request) {
        log.info("Register request received for username: {}", request.getUsername());
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            log.warn("Registration failed: username {} already exists", request.getUsername());
            throw new RuntimeException("Username already exists!");
        }

        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .build();

        userRepository.save(user);
        log.info("User registered successfully: {}", user.getUsername());
        return "User registered successfully!";
    }

    public String login(LoginRequest request) {
        log.info("Login request for username: {}", request.getUsername());

        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found."));
        log.warn("Login failed: user {} not found", request.getUsername());

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            log.warn("Login failed: invalid password for user {}", request.getUsername());

            throw new RuntimeException("Invalid password.");
        }

        String token =  jwtService.generateToken(user);
        log.info("Login successful for user {}", request.getUsername());
        return token;
    }

}
