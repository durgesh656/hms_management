package com.hms.billing_and_payment_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillingAndPaymentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillingAndPaymentServiceApplication.class, args);
	}

}
