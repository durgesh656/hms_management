package com.hms.billing_and_payment_service.services;

import com.hms.billing_and_payment_service.entities.Payment;
import com.hms.billing_and_payment_service.repositories.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService{

    private final PaymentRepository paymentRepository;

    @Override
    public Payment makePayment(Payment payment) {
        log.info("Saving payment: {}", payment);
        payment.setPaymentDate(java.time.LocalDateTime.now());
        payment.setPaymentStatus(true); // For now, default it to true
        Payment saved =  paymentRepository.save(payment);
        log.info("Payment saved successfully with ID: {}", saved.getId());
        return saved;
    }

    @Override
    public List<Payment> getAllPayments() {
        log.info("Retrieving all payments from database");

        return paymentRepository.findAll();
    }

    @Override
    public Optional<Payment> getPaymentById(Long id) {
        log.info("Looking up payment with ID: {}", id);
        return paymentRepository.findById(id);
    }

    @Override
    public void deletePayment(Long id) {
        log.info("Deleting payment with ID: {}", id);
        paymentRepository.deleteById(id);
        log.info("Payment with ID {} has been deleted", id);    }
}
