package com.hms.room_management_service.controller;


import com.hms.room_management_service.entities.Room;
import com.hms.room_management_service.services.RoomService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/rooms")

public class RoomController {
    private final RoomService roomService;

    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    @PostMapping
    public ResponseEntity<Room> addRoom(@Valid @RequestBody Room room) {
        log.info("Received request to add room: {}", room);
        Room savedRoom = roomService.addRoom(room);
        log.info("Room added successfully: {}", savedRoom);
        return ResponseEntity.ok(savedRoom);
    }

    @GetMapping
    public ResponseEntity<List<Room>> getAllRooms() {
        log.info("Received request to get all rooms");
        List<Room> rooms = roomService.getAllRooms();
        log.info("Returning {} rooms", rooms.size());
        return ResponseEntity.ok(rooms);    }

    @GetMapping("/{id}")
    public ResponseEntity<Room> getRoomById(@PathVariable Long id) {
        log.info("Received request to get room with ID: {}", id);
        return roomService.getRoomById(id)
                .map(room -> {
                    log.info("Room found: {}", room);
                    return ResponseEntity.ok(room);
                })
                .orElseGet(() -> {
                    log.warn("Room with ID {} not found", id);
                    return ResponseEntity.notFound().build();
                });
    }

//    @PutMapping("/{id}")
//    public ResponseEntity<Room> updateRoom(@PathVariable Long id, @RequestBody Room room) {
//        Room updated = roomService.updateRoom(id, room);
//        return updated != null ? ResponseEntity.ok(updated) : ResponseEntity.notFound().build();
//    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRoom(@PathVariable Long id) {
        log.info("Received request to delete room with ID: {}", id);
        roomService.deleteRoom(id);
        log.info("Room with ID {} deleted", id);
        return ResponseEntity.noContent().build();
    }
}
