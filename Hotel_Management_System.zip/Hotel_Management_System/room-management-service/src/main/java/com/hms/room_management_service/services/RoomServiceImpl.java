package com.hms.room_management_service.services;

import com.hms.room_management_service.entities.Room;
import com.hms.room_management_service.repositories.RoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service

public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;

    public RoomServiceImpl(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }


    @Override
    public Room addRoom(Room room) {
        log.info("Adding new room: {}", room);
        Room savedRoom = roomRepository.save(room);
        log.info("Room saved with ID: {}", savedRoom.getId());
        return savedRoom;
    }

    @Override
    public List<Room> getAllRooms() {
        log.info("Fetching all rooms");
        return roomRepository.findAll();
    }

    @Override
    public Optional<Room> getRoomById(Long id) {
        log.info("Fetching room with ID: {}", id);
        return roomRepository.findById(id);
    }

//    @Override
//    public Room updateRoom(Long id, Room room) {
//        return roomRepository.findById(id).map(existing -> {
//            existing.setRoomNumber(room.getRoomNumber());
//            existing.setType(room.getType());
//            existing.setPrice(room.getPrice());
//            existing.setAvailable(room.isAvailable());
//            return roomRepository.save(existing);
//        }).orElse(null);
//    }

    @Override
    public void deleteRoom(Long id) {
        log.info("Deleting room with ID: {}", id);
        roomRepository.deleteById(id);
        log.info("Room with ID {} deleted", id);
    }
}
