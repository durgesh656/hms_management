package com.hms.room_management_service.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "Room number is mandatory")
    private String roomNumber;
    @NotBlank
    private String type; // e.g., Single, Double, Suite
    @NotNull(message = "Price must be provided")
    @Positive(message = "Price must be positive")
    private Double price;

    private boolean available;

//    @Override
//    public String toString() {
//        return "Room{" +
//                "id=" + id +
//                ", roomNumber='" + roomNumber + '\'' +
//                ", type='" + type + '\'' +
//                ", price=" + price +
//                ", available=" + available +
//                '}';
//    }
}
