import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { UserNavbar } from '../../components/navbar/user-navbar/user-navbar';

@Component({
  selector: 'app-rooms',
  standalone: true,
  imports: [CommonModule, HttpClientModule, UserNavbar],
  templateUrl: './rooms.html',
  styleUrls: ['./rooms.css']
  
})
export class Rooms implements OnInit {
  rooms: any[] = [];
  error: string = '';
  selectedType: string = ''; // for filtering room type

  constructor(
    private http: HttpClient,
    private router: Router
  ) {}

  

  ngOnInit(): void {
    this.loadAvailableRooms();
  }

  loadAvailableRooms() {
  this.http.get<any[]>('http://localhost:8084/api/rooms', {
    headers: { 'X-Role': 'USER' }
  }).subscribe({
    next: (res) => {
      this.rooms = res.map(room => ({
        ...room,
        status: room.available ? 'Available' : 'Booked',
        price:
    room.type === 'Single' ? 2000 :
    room.type === 'Deluxe' ? 3000 :
    room.type === 'VIP' ? 4000 : 'N/A'
      }));
    },
    error: (err) => {
      this.error = 'Failed to load rooms: ' + (err.error?.message || 'Unknown error');
    }
  });
}

  bookRoom(room: any) {
    // Here you can route to booking or login page
    console.log('Room selected for booking:', room);
    this.router.navigate(['/book-room']); // Or use a booking route if user is logged in
  }
}
