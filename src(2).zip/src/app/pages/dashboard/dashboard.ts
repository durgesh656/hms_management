import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { UserNavbar } from '../../components/navbar/user-navbar/user-navbar';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule,UserNavbar],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css']
})
export class Dashboard {
  constructor(private router: Router) {}

  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}
