import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient , HttpClientModule} from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { UserNavbar } from "../../components/navbar/user-navbar/user-navbar";

@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule, UserNavbar],
  templateUrl: './booking.html',
  styleUrls: ['./booking.css']
})
export class Booking implements OnInit {
  bookingForm!: FormGroup;
  roomType: string = '';
  roomId!: number;
  today: any;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router
  ) {}
  loading = false;

  ngOnInit(): void {
    // Optional: You could get roomType or ID from query param if passed
     this.today = new Date().toISOString().split('T')[0]; // Format: yyyy-MM-dd
    this.bookingForm = this.fb.group({
      // guestId: ['', Validators.required],
      guestName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      roomType: ['', Validators.required],
      checkInDate: ['', Validators.required],
      checkOutDate: ['', Validators.required]
    });
  }

  submitBooking() {
  if (this.bookingForm.valid) {
    const bookingData = this.bookingForm.value;
      console.log('Form Data:', bookingData); 
    this.http.post('http://localhost:8085/api/bookings', bookingData).subscribe({
      next: (response: any) => {
        console.log('Booking successful:', response);
        const bookingId = response.id;

        // ✅ Redirect to payment page with booking ID
        this.router.navigate(['/payment', bookingId]);
      },
      error: (err) => {
        console.error('Booking failed:', err);
        alert('Booking failed: ' + (err.error?.message || 'Unknown error'));
      }
    });
  } else {
    alert('Please fill in all booking details.');
  }
}

}
