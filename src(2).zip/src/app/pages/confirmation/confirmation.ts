import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-confirmation',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './confirmation.html',
  styleUrls: ['./confirmation.css']
})
export class Confirmation implements OnInit {
  bookingId!: number;
  booking: any;

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.bookingId = +this.route.snapshot.paramMap.get('id')!;
    this.fetchBookingDetails();
  }

  fetchBookingDetails() {
    this.http.get<any>(`http://localhost:8085/api/bookings/${this.bookingId}`).subscribe({
      next: (data) => {
        this.booking = data;
      },
      error: () => {
        alert('Failed to load booking details.');
        this.router.navigate(['/dashboard']);
      }
    });
  }

  goHome() {
    this.router.navigate(['/dashboard']);
  }
}
