import { Component } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { Navbar } from "../../components/navbar/navbar";

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule, Navbar],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class Register {
  registerForm: FormGroup;

  // ✅ Password toggle
  showPassword: boolean = false;
submitted: any;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router
  ) {
    // ✅ Initialize form inside constructor
    this.registerForm = this.fb.group({
      fullName: ['', Validators.required],
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role: ['USER', Validators.required]
    });
  }

  // ✅ Method to toggle password visibility
  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  // ✅ Form submission logic
  onSubmit() {
    if (this.registerForm.valid) {
      const userData = this.registerForm.value;
      this.http.post('http://localhost:8082/api/registration/register', userData)
        .subscribe({
          next: (response) => {
            alert('Registered successfully! Please log in.');
            this.router.navigate(['/login']);
          },
          error: (err: any) => {
            alert('Registration failed: ' + (err?.error?.message || 'Unknown error'));
          }
        });
    } else {
      alert('Form is invalid');
    }
  }
}
