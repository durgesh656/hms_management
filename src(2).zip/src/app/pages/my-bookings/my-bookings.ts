import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [CommonModule, RouterModule, HttpClientModule],
  templateUrl: './my-bookings.html',
  styleUrls: ['./my-bookings.css']
})
export class MyBookings implements OnInit {
  bookings: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    const token = localStorage.getItem('token');
    const decoded: any = JSON.parse(atob(token!.split('.')[1]));
    const guestId = decoded.subId; // Adjust based on your JWT payload

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });

    this.http.get<any[]>(`http://localhost:8085/api/bookings/guest/${guestId}`, { headers })
      .subscribe({
        next: data => this.bookings = data,
        error: err => alert('Failed to fetch bookings')
      });
  }
}
