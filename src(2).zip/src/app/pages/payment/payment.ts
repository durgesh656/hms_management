import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './payment.html',
  styleUrls: ['./payment.css']
})
export class Payment implements OnInit {
  paymentForm: FormGroup;
  bookingId!: number;
  successMessage = '';
  errorMessage = '';
  amount = 0;

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router
  ) {
    this.paymentForm = this.fb.group({
      paymentMethod: ['card', Validators.required]
    });
  }

  ngOnInit(): void {
    this.bookingId = +this.route.snapshot.paramMap.get('id')!;
    this.getBookingDetails();
  }

  getBookingDetails() {
    this.http.get<any>(`http://localhost:8085/api/bookings/${this.bookingId}`).subscribe({
      next: (booking) => {
        this.amount = booking.totalAmount;
      },
      error: () => {
        this.errorMessage = 'Failed to fetch booking details.';
      }
    });
  }

  makePayment() {
    if (this.paymentForm.valid) {
      const paymentData= {
        bookingId: this.bookingId,
        amount: this.amount,
        paymentMethod: this.paymentForm.value.paymentMethod
      };

      this.http.post('http://localhost:8086/api/payments', paymentData).subscribe({
        next: () => {
          this.successMessage = 'Payment successful!';
          alert('Booking successful! Payment completed.');
           // Navigate to confirmation page with bookingId
            //this.router.navigate(['/confirmation', paymentData.bookingId]);  // ✅ PLACE IT HERE
          this.router.navigate(['/dashboard']);
        },
        error: (err) => {
          console.error(err);
          this.errorMessage = 'Payment failed: ' + (err.error?.message || 'Try again later');
        }
      });
    }
  }
}

// makePayment() {
//   if (this.paymentForm.valid) {
//     const paymentData = {
//       ...this.paymentForm.value,
//       amount: this.amount,         // if required by backend
//       bookingId: this.bookingId    // if needed
//     };

//     this.loading = true;
//     this.http.post('http://localhost:8086/api/payments', paymentData).subscribe({
//       next: (res) => {
//         this.successMessage = 'Payment successful!';
//         this.errorMessage = '';
//         this.loading = false;

//         // 👇 Redirect after short delay (2 seconds)
//         setTimeout(() => {
//           this.router.navigate(['/user-dashboard']);
//         }, 2000);
//       },
//       error: (err) => {
//         this.errorMessage = err.error?.message || 'Payment failed. Please try again.';
//         this.successMessage = '';
//         this.loading = false;
//       }
//     });
//   }
// }
