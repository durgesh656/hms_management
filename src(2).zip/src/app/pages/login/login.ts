import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AuthService } from '../../services/auth.service';
import { Navbar } from "../../components/navbar/navbar";

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule, Navbar],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class Login {
  loginForm: FormGroup;
  errorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    //private authService: AuthService,
    private http: HttpClient,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

//  loginUser() {
//   if (this.loginForm.valid) {
//     const credentials = this.loginForm.value;

//     this.authService.login(credentials).subscribe({
//       next: (res: any) => {
//         const token = res.token;

//         if (token) {
//           this.authService.saveToken(token); // ✅ Save token in localStorage

//           const role = this.authService.getUserRole(); // ✅ Decode role from token

//           if (role === 'admin') {
//             this.router.navigate(['/admin-dashboard']);
//           } else {
//             this.router.navigate(['/user-dashboard']);
//           }
//         } else {
//           this.errorMessage = 'No token received from server';
//         }
//       },
//       error: (err) => {
//         this.errorMessage = err.error?.error || 'Invalid credentials';
//         console.error('Login failed:', err);
//       }
//     });
//   } else {
//     this.errorMessage = 'Please fill in all fields correctly.';
//   }
//}
  showPassword: boolean = false;

togglePassword() {
  this.showPassword = !this.showPassword;
}


  loginUser() {
  if (this.loginForm.valid) {
    const credentials = this.loginForm.value;

    this.http.post('http://localhost:8082/api/registration/login', credentials)
      .subscribe({
        next: (response: any) => {
          const token = response.token;

          if (token) {
            localStorage.setItem('token', token); // ✅ Save token
            alert('Login successful!');
            this.router.navigate(['/dashboard']);
          } else {
            this.errorMessage = 'No token received from server';
          }
          console.log('Login successful:', response);
          console.log('Token:', token);
        },
        error: (err) => {
          console.error('Login failed:', err);
          if (err.status === 401) {
            this.errorMessage = 'Invalid username or password';
          } else {
            alert('Login failed: ' + (err.error?.error || 'Unknown error'));
          }
        }
      });
  } else {
    alert('Please fill in all fields correctly.');
  }
}

  }
