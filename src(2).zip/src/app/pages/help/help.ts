import { Component } from '@angular/core';
import { Navbar } from "../../components/navbar/navbar";

@Component({
  selector: 'app-help',
  imports: [Navbar],
  templateUrl: './help.html',
  styleUrl: './help.css'
})
export class Help {

}
