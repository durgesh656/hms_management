import { Routes } from '@angular/router';
import { Home } from './pages/home/home';
import { Login } from './pages/login/login';
import { Register } from './pages/register/register';
import { About } from './pages/about/about';
import { Help } from './pages/help/help';
import { Dashboard } from './pages/dashboard/dashboard';
import { AuthGuard } from './services/auth.guard';
import { Rooms } from './pages/rooms/rooms';
import { Booking } from './pages/booking/booking';
import { Payment } from './pages/payment/payment';
import { Confirmation } from './pages/confirmation/confirmation';
import { MyBookings } from './pages/my-bookings/my-bookings';

export const routes: Routes = [
  { path: '', component: Home },
  { path: 'login', component: Login },
  { path: 'register', component: Register },
  { path: 'about', component: About },
  { path: 'help', component: Help },
  { path: 'dashboard', component: Dashboard },
  {path: 'dashboard', component: Dashboard, canActivate: [AuthGuard] },
  { path: 'rooms', component: Rooms, canActivate: [AuthGuard] },
  { path: 'book-room', component: Booking,},
  { path: 'payment/:id', component: Payment },
  { path: 'confirmation/:id', component: Confirmation },
  { path: 'my-bookings', component: MyBookings, canActivate: [AuthGuard] },
  { path: '**', redirectTo: '' }
];
