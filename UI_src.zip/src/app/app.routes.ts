// import { Routes } from '@angular/router';

// export const routes: Routes = [];


import { Routes } from '@angular/router';
import { Home } from './components/home/home';
import { Register } from './components/register/register';
import { Login } from './components/login/login';
//import { Rooms } from './components/rooms/rooms';
//import { Bookings } from './components/bookings/bookings';
//import { Contact } from './components/contact/contact';


export const routes: Routes = [
  { path: '', component: Home },
  { path: 'register', component: Register },
  { path: 'login', component: Login },
  //{ path: 'rooms', component: Rooms },
  //{ path: 'bookings', component: Bookings },
  //{ path: 'contact', component: Contact },
];



// import { Routes } from '@angular/router';
// import { HomeComponent } from './components/home/home.component';
// import { RegisterComponent } from './components/register/register.component';
// import { LoginComponent } from './components/login/login.component';

// export const routes: Routes = [
//   { path: '', component: HomeComponent },
//   { path: 'register', component: RegisterComponent },
//   { path: 'login', component: LoginComponent },
// ];

