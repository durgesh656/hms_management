// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-register',
//   imports: [],
//   templateUrl: './register.html',
//   styleUrl: './register.css'
// })
// export class Register {

// }




import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class Register {
  formData = {
    fullName: '',
    email: '',
    password: '',
    role: ''
  };

  roles = ['OWNER', 'MANAGER', 'RECEPTIONIST'];

  onSubmit(form: NgForm) {
    if (form.valid) {
      console.log('Form Data:', this.formData);
      alert('Registration successful!');
      form.resetForm();
    }
  }
}
