import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-rooms',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './rooms.html',
  styleUrls: ['./rooms.css']
})
export class Rooms {
  rooms = [
    {
      name: 'Deluxe Room',
      description: 'A spacious room with king-size bed and balcony.',
      price: 3000,
      image: 'https://unsplash.com/photos/white-bed-comforter-near-table-lamp-g5ZIXjzRGds'
    },
    {
      name: 'Executive Suite',
      description: 'Luxury suite with city view and free breakfast.',
      price: 4500,
      image: 'C:/Users/sanjayrajpoot/Desktop/H_Frontend/hotel-ui/src/app/components/rooms/img1.jpg'
    },
    {
      name: 'Standard Room',
      description: 'Comfortable room with all basic amenities.',
      price: 1800,
      image: 'assets/images/rooms/image.jpg'
    }

  ];
}

