// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-bookings',
//   imports: [],
//   templateUrl: './bookings.html',
//   styleUrl: './bookings.css'
// })
// export class Bookings {

// }



import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-bookings',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bookings.html',
  styleUrls: ['./bookings.css']
})
export class Bookings {
  bookings = [
    {
      guestName: 'Sanjay Kumar',
      roomType: 'Deluxe Room',
      checkIn: '2025-07-10',
      checkOut: '2025-07-12',
      status: 'Confirmed',
    },
    {
      guestName: 'Anjali Mehta',
      roomType: 'Executive Suite',
      checkIn: '2025-07-15',
      checkOut: '2025-07-18',
      status: 'Pending',
    },
    {
      guestName: 'Ravi Patel',
      roomType: 'Standard Room',
      checkIn: '2025-07-20',
      checkOut: '2025-07-22',
      status: 'Cancelled',
    }
  ];
}
