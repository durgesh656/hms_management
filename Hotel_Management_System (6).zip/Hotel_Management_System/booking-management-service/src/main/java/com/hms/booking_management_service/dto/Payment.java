package com.hms.booking_management_service.dto;

import lombok.Data;

@Data
public class Payment {
    private Long id;
    private Long bookingId;
    private Double amount;
    private String status;
    // getters & setters
}
