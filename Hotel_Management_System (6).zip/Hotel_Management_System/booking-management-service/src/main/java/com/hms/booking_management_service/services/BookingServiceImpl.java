package com.hms.booking_management_service.services;

import com.hms.booking_management_service.entities.Booking;
import com.hms.booking_management_service.feign.PaymentServiceClient;
import com.hms.booking_management_service.dto.*;
import com.hms.booking_management_service.feign.RoomServiceClient;
import com.hms.booking_management_service.repositories.BookingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final RoomServiceClient roomServiceClient;
    private final PaymentServiceClient paymentServiceClient;

    @Override
    public Booking createBooking(Booking booking) {
        log.info("Checking room availability for type: {}", booking.getRoomType());

        // Get available room from Room Service
        Room availableRoom = roomServiceClient.getAvailableRoomByType(booking.getRoomType(), "USER");
        if (availableRoom == null || !Boolean.TRUE.equals(availableRoom.getAvailable())) {
            throw new RuntimeException("No available rooms of type: " + booking.getRoomType());
        }

        booking.setRoomId(availableRoom.getId());

        // Fixed pricing logic
        double price = switch (booking.getRoomType().toLowerCase()) {
            case "single" -> 2000.0;
            case "deluxe" -> 3000.0;
            case "vip" -> 4000.0;
            default -> throw new RuntimeException("Invalid room type: " + booking.getRoomType());
        };
        booking.setRoomPrice(price);

        // Stay duration calculation
        long days = ChronoUnit.DAYS.between(booking.getCheckInDate(), booking.getCheckOutDate());
        if (days <= 0) {
            throw new RuntimeException("Invalid stay duration. Check-out date must be after check-in date.");
        }

        // Set total and booking date
        booking.setTotalAmount(price * days);
        booking.setBookingDate(LocalDate.now());

        // Mark room as unavailable
        roomServiceClient.updateRoomAvailability(availableRoom.getId(), false, "USER");

        // Save booking
        Booking saved = bookingRepository.save(booking);
        log.info("Booking saved with ID: {}", saved.getId());

        // Generate bill via Payment Service
        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setBookingId(saved.getId());
        paymentRequest.setGuestId(saved.getGuestId());
        paymentRequest.setAmount(saved.getTotalAmount());
        paymentRequest.setPaymentMethod("CASH");

        Payment payment = paymentServiceClient.generateBill(paymentRequest);
        log.info("Payment generated: {}", payment);

        return saved;
    }



    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    @Override
    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }
}
