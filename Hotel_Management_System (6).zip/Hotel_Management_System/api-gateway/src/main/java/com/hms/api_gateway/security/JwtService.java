package com.hms.api_gateway.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import java.security.Key;

@Service
public class JwtService {

    private static final String SECRET_KEY = "your-very-secret-key-your-very-secret-key"; // 256-bit

    private final Key key = Keys.hmacShaKeyFor(SECRET_KEY.getBytes());

    private final JwtParser jwtParser = Jwts.parserBuilder()
            .setSigningKey(key)
            .build();

    // ✅ Validates the token
    public void validateToken(String token) {
        jwtParser.parseClaimsJws(token); // throws exception if token is invalid
    }

    // ✅ Extract all claims
    public Claims extractClaims(String token) {
        return jwtParser.parseClaimsJws(token).getBody();
    }

    // ✅ Extract username
    public String extractUsername(String token) {
        return extractClaims(token).getSubject(); // "sub" claim
    }

    // ✅ Extract role
    public String extractRole(String token) {
        return extractClaims(token).get("role", String.class);
    }

    // ✅ Extract user ID
    public Long extractUserId(String token) {
        return extractClaims(token).get("userId", Long.class);
    }
}
