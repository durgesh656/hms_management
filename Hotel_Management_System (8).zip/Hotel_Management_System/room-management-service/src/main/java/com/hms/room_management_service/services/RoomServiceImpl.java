package com.hms.room_management_service.services;

import com.hms.room_management_service.dto.RoomStatusResponse;
import com.hms.room_management_service.entities.Room;
import com.hms.room_management_service.repositories.RoomRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;

    public RoomServiceImpl(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    @Override
    public Room addRoom(Room room) {
        long roomCount = roomRepository.count();
        if (roomCount >= 20) {
            log.warn("Cannot add room. Hotel is full. Current room count: {}", roomCount);
            throw new IllegalStateException("Hotel is full. Cannot add more rooms.");
        }
        log.info("Adding new room: {}", room);
        Room savedRoom = roomRepository.save(room);
        log.info("Room saved with ID: {}", savedRoom.getId());
        return savedRoom;
    }

    @Override
    public List<Room> getAllRooms() {
        log.info("Fetching all rooms");
        return roomRepository.findAll();
    }

    public List<Room> getAvailableRooms() {
        log.info("Fetching available rooms only");
        return roomRepository.findAll().stream()
                .filter(Room::isAvailable)
                .toList();
    }

    @Override
    public Optional<Room> getRoomById(Long id) {
        log.info("Fetching room with ID: {}", id);
        return roomRepository.findById(id);
    }

    @Override
    public void deleteRoom(Long id) {
        log.info("Deleting room with ID: {}", id);
        roomRepository.deleteById(id);
        log.info("Room with ID {} deleted", id);
    }

    // RoomServiceImpl.java
    @Override
    public RoomStatusResponse getRoomStatus() {
        long total = roomRepository.count();
        long available = roomRepository.countByAvailableTrue();
        long booked = roomRepository.countByAvailableFalse();
        return new RoomStatusResponse(total, booked, available);
    }

    @Override
    public Room saveRoom(Room room) {
        log.info("Updating room with ID: {}", room.getId());
        return roomRepository.save(room);
    }

    @Override
    public void updateRoomAvailability(Long roomId, boolean available) {
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new IllegalArgumentException("Room not found with ID: " + roomId));
        room.setAvailable(available);
        roomRepository.save(room);
        log.info("Room ID {} availability updated to {}", roomId, available);
    }


}
