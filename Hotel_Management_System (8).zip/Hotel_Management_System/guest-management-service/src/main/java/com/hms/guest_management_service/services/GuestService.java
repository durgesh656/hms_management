package com.hms.guest_management_service.services;

import com.hms.guest_management_service.dto.GuestRequest;
import com.hms.guest_management_service.entities.Guest;
import com.hms.guest_management_service.exception.GuestNotFoundException;
import com.hms.guest_management_service.repositories.GuestRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class GuestService {
    private final GuestRepository guestRepository;

    public Guest addGuest(Guest guest) {
        log.info("Saving guest: {}", guest);
        return guestRepository.save(guest);
    }

    public List<Guest> getAllGuests() {
        log.info("Fetching all guests");
        return guestRepository.findAll();
    }

    public Optional<Guest> getGuestById(Long id) {
        log.info("Fetching guest with ID: {}", id);
        return guestRepository.findById(id);
    }

    public Guest updateGuest(Long id, Guest guestDetails) {
        log.info("Updating guest with ID: {}", id);
        return guestRepository.findById(id).map(guest -> {
            guest.setName(guestDetails.getName());
            guest.setPhoneNumber(guestDetails.getPhoneNumber());
            guest.setEmail(guestDetails.getEmail());
            guest.setAddress(guestDetails.getAddress());
            log.info("Guest data updated for ID: {}", id);
            return guestRepository.save(guest);
        }).orElse(null);
    }

    public void updateGuestBooking(Long guestId, String guestName, Long roomId, LocalDate checkInDate, LocalDate checkOutDate) {
        Optional<Guest> optionalGuest = guestRepository.findById(guestId);

        if (optionalGuest.isPresent()) {
            Guest guest = optionalGuest.get();
            guest.setName(guestName); // ✅ Update name from booking input
            guest.setRoomId(roomId);
            guest.setCheckInDate(checkInDate);
            guest.setCheckOutDate(checkOutDate);

            guestRepository.save(guest);
        } else {
            throw new GuestNotFoundException("Guest with ID " + guestId + " not found.");
        }
    }

    public void updateOrAddGuestFromBooking(GuestRequest request) {
        Optional<Guest> optionalGuest = guestRepository.findById(request.getGuestId());

        Guest guest = optionalGuest.orElse(new Guest());
        guest.setId(request.getGuestId());
        guest.setName(request.getGuestName());
        guest.setEmail(request.getEmail());
        guest.setPhoneNumber(request.getMobile());
        guest.setRoomId(request.getRoomId());
        guest.setCheckInDate(request.getCheckInDate());
        guest.setCheckOutDate(request.getCheckOutDate());

        guestRepository.save(guest);
        log.info("Guest saved/updated from booking: {}", guest.getId());
    }

    public void saveNewGuestFromBooking(GuestRequest request) {
        Guest guest = Guest.builder()
                .name(request.getGuestName())
                .email(request.getEmail())
                .phoneNumber(request.getMobile())
                .roomId(request.getRoomId())
                .checkInDate(request.getCheckInDate())
                .checkOutDate(request.getCheckOutDate())
                .address("Auto-created from booking")
                .build();

        guestRepository.save(guest);
    }


    public void deleteGuest(Long id) {
        log.info("Deleting guest with ID: {}", id);
        guestRepository.deleteById(id);
        log.info("Guest with ID {} deleted", id);
    }
}
