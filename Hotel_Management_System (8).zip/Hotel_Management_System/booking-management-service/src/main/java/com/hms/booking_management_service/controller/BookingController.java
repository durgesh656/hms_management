package com.hms.booking_management_service.controller;

import com.hms.booking_management_service.entities.Booking;
import com.hms.booking_management_service.services.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    @PostMapping
    public ResponseEntity<?> createBooking(@Valid @RequestBody Booking booking) {
        log.info("Received request to create booking: {}", booking);
        try {
            Booking saved = bookingService.createBooking(booking);
            log.info("Booking created successfully with ID: {}", saved.getId());
            return ResponseEntity.ok(saved);
        } catch (RuntimeException e) {
            log.error("Error occurred while creating booking: {}", e.getMessage());
            return ResponseEntity.badRequest().body("Failed to create booking: " + e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<List<Booking>> getAllBookings() {
        log.info("Received request to fetch all bookings");
        List<Booking> bookings = bookingService.getAllBookings();
        log.info("Returning {} bookings", bookings.size());
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getBookingById(@PathVariable Long id) {
        log.info("Received request to fetch booking with ID: {}", id);
        return bookingService.getBookingById(id)
                .map(booking -> {
                    log.info("Booking found: {}", booking);
                    return ResponseEntity.ok(booking);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBooking(@PathVariable Long id) {
        log.info("Received request to delete booking with ID: {}", id);
        bookingService.deleteBooking(id);
        log.info("Booking with ID {} deleted successfully", id);
        return ResponseEntity.ok("Booking deleted successfully with ID: " + id);
    }
}
