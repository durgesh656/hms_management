//package com.hms.booking_management_service.excetions;
//
//public class GuestNotFoundException extends RuntimeException{
//    GuestNotFoundException(String message){
//        super(message);
//    }
//}
