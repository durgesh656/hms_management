package com.hms.booking_management_service.dto;

import lombok.Data;

@Data
public class Room {
    private Long id;
    private String roomType;
    private Double price;
    private Boolean available;
    // getters & setters
}
