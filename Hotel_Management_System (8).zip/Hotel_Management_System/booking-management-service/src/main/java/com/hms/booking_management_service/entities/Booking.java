package com.hms.booking_management_service.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Guest ID cannot be null")
    private Long guestId;

    @NotBlank(message="Guest name is required")
    String guestName;

    @NotBlank(message = "Email is required")
    private String email;

    @NotBlank(message = "Mobile is required")
    private String mobile;


    @NotNull(message = "Room ID cannot be null")
    private Long roomId;

    @NotNull(message = "Room type cannot be null")
    private String roomType;

//    @NotNull(message = "Room price cannot be null")
    private Double roomPrice;

    @FutureOrPresent(message = "Check-in date must be today or in the future")
    @NotNull(message = "Check-in date is required")
    private LocalDate checkInDate;

    @FutureOrPresent(message = "Check-out date must be today or in the future")
    @NotNull(message = "Check-out date is required")
    private LocalDate checkOutDate;

   // @NotNull
    private Double totalAmount;

    @NotNull
    @Column(name = "booking_date")
    private LocalDate bookingDate;
}
