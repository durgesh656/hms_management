package com.hms.booking_management_service.feign;

import com.hms.booking_management_service.dto.GuestRequest;
import com.hms.booking_management_service.entities.Booking;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;

@FeignClient(name = "guest-management-service")
public interface GuestServiceClient {

    @PostMapping("/api/guests/add-booking-info") // ✅ CORRECT
    void addGuestInfo(@RequestBody GuestRequest guestRequest);
}

