package com.hms.booking_management_service.dto;

import lombok.Data;

@Data
public class PaymentRequest {
    private Long bookingId;
    private Long guestId;
    private Double amount;
    private String paymentMethod;
    // getters & setters
}
