package com.hms.booking_management_service.feign;

import com.hms.booking_management_service.dto.Room;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "room-management-service")
public interface RoomServiceClient {

    @GetMapping("/api/rooms/available/{roomType}")
    Room getAvailableRoomByType(
            @PathVariable("roomType") String type,
            @RequestHeader("X-Role") String role
    );

    @PutMapping("/api/rooms/{id}/availability")
    void updateRoomAvailability(
            @PathVariable("id") Long id,
            @RequestParam("available") boolean available,
            @RequestHeader("X-Role") String role
    );
}
