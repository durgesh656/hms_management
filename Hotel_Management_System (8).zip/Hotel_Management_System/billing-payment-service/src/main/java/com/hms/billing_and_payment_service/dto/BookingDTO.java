package com.hms.billing_and_payment_service.dto;

import lombok.Data;

@Data
public class BookingDTO {
    private Long id;
    private String roomType;
    private Long userId;
    private String checkInDate;
    private String checkOutDate;
}