package com.hms.billing_and_payment_service.services;

import com.hms.billing_and_payment_service.dto.BookingDTO;
import com.hms.billing_and_payment_service.entities.Payment;
import com.hms.billing_and_payment_service.exception.DuplicatePaymentException;
import com.hms.billing_and_payment_service.feign.BookingClient;
import com.hms.billing_and_payment_service.repositories.PaymentRepository;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingClient bookingClient;

    @Override
    public Payment makePayment(Payment payment) {
        Long bookingId = payment.getBookingId();

        if (paymentRepository.existsByBookingId(bookingId)) {
            throw new DuplicatePaymentException("Payment already exists for Booking ID: " + bookingId);
        }

        BookingDTO booking = null;
        try {
            booking = bookingClient.getBookingById(bookingId);
            if (booking == null) {
                throw new DuplicatePaymentException("Booking not found for ID: " + bookingId);
            }
        } catch (Exception ex) {
            log.error("Booking validation failed: {}", ex.getMessage());
            throw new DuplicatePaymentException("Failed to validate Booking ID " + bookingId);
        }

        try {
            Map<String, Object> params = new HashMap<>();
            params.put("amount", Math.round(payment.getAmount() * 100)); // in paisa
            params.put("currency", "inr");
            params.put("payment_method_types", List.of("card"));
            params.put("description", "Payment for Booking ID: " + bookingId);

            PaymentIntent intent = PaymentIntent.create(params);

            payment.setPaymentDate(LocalDateTime.now());
            payment.setPaymentStatus(true);

            Payment saved = paymentRepository.save(payment);
            log.info("Stripe payment successful. ID: {}", intent.getId());

            return saved;

        } catch (StripeException e) {
            log.error("Stripe error: {}", e.getMessage());
            throw new DuplicatePaymentException("Stripe payment failed: " + e.getMessage());
        }
    }




    @Override
    public List<Payment> getAllPayments() {
        log.info("Fetching all payments");
        return paymentRepository.findAll();
    }

    @Override
    public Optional<Payment> getPaymentById(Long id) {
        log.info("Fetching payment by ID: {}", id);
        return paymentRepository.findById(id);
    }

    @Override
    public void deletePayment(Long id) {
        log.info("Deleting payment ID: {}", id);
        paymentRepository.deleteById(id);
        log.info("Deleted payment ID: {}", id);
    }
}
