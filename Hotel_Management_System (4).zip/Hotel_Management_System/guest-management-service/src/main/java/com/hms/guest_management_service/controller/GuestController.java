package com.hms.guest_management_service.controller;

import com.hms.guest_management_service.entities.Guest;
import com.hms.guest_management_service.services.GuestService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/guests")
@RequiredArgsConstructor
public class GuestController {
    private final GuestService guestService;

    @PostMapping
    public ResponseEntity<Guest> addGuest(@Valid @RequestBody Guest guest) {
        log.info("Received request to add guest: {}", guest);
        Guest savedGuest = guestService.addGuest(guest);
        log.info("Guest added successfully with ID: {}", savedGuest.getId());
        return ResponseEntity.ok(savedGuest);    }

    @GetMapping
    public ResponseEntity<List<Guest>> getAllGuests() {
        log.info("Received request to get all guests");
        return ResponseEntity.ok(guestService.getAllGuests());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Guest> getGuestById(@PathVariable Long id) {
        log.info("Received request to get guest with ID: {}", id);
        return guestService.getGuestById(id)
                .map(guest -> {
                    log.info("Guest found: {}", guest);
                    return ResponseEntity.ok(guest);
                })
                .orElseGet(() -> {
                    log.warn("Guest with ID {} not found", id);
                    return ResponseEntity.notFound().build();
                });
    }

    @PutMapping("/{id}")
    public ResponseEntity<Guest> updateGuest(@PathVariable Long id,@Valid @RequestBody Guest guest) {
        log.info("Received request to update guest with ID: {}", id);
        Guest updated = guestService.updateGuest(id, guest);
        if (updated != null) {
            log.info("Guest with ID {} updated successfully", id);
            return ResponseEntity.ok(updated);
        } else {
            log.warn("Guest with ID {} not found for update", id);
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGuest(@PathVariable Long id) {
        log.info("Received request to delete guest with ID: {}", id);
        guestService.deleteGuest(id);
        log.info("Guest with ID {} deleted successfully", id);
        return ResponseEntity.noContent().build();
    }
}
