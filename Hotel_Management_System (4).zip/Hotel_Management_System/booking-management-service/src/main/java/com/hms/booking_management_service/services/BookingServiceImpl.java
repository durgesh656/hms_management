package com.hms.booking_management_service.services;

import com.hms.booking_management_service.dto.*;
import com.hms.booking_management_service.entities.Booking;
import com.hms.booking_management_service.feign.GuestServiceClient;
import com.hms.booking_management_service.feign.PaymentServiceClient;
import com.hms.booking_management_service.feign.RoomServiceClient;
import com.hms.booking_management_service.repositories.BookingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final RoomServiceClient roomServiceClient;
    private final PaymentServiceClient paymentServiceClient;
    private final GuestServiceClient guestServiceClient;

    @Override
    public Booking createBooking(Long guestId, BookingRequest request) {
        log.info("Checking availability for room type: {}", request.getRoomType());

        // Step 1: Get available room
        Room availableRoom = roomServiceClient.getAvailableRoomByType(request.getRoomType());
        if (availableRoom == null || !Boolean.TRUE.equals(availableRoom.getAvailable())) {
            throw new RuntimeException("No available rooms of type: " + request.getRoomType());
        }

        log.info("Available room found: {}", availableRoom.getId());

        // Step 2: Calculate price and total
        double price = switch (request.getRoomType().toLowerCase()) {
            case "single" -> 2000.0;
            case "deluxe" -> 3000.0;
            case "vip" -> 4000.0;
            default -> throw new RuntimeException("Invalid room type: " + request.getRoomType());
        };

        long days = ChronoUnit.DAYS.between(request.getCheckInDate(), request.getCheckOutDate());
        if (days <= 0) {
            throw new RuntimeException("Invalid stay duration. Check-out must be after check-in.");
        }

        double totalAmount = price * days;

        // Step 3: Update room availability (mark as booked)
        log.info("Updating room availability to false for roomId={}", availableRoom.getId());
        roomServiceClient.updateRoomAvailability("USER", availableRoom.getId(), false);

        // Step 4: Save booking
        Booking booking = Booking.builder()
                .guestId(guestId)
                .roomId(availableRoom.getId())
                .roomType(request.getRoomType())
                .roomPrice(price)
                .checkInDate(request.getCheckInDate())
                .checkOutDate(request.getCheckOutDate())
                .totalAmount(totalAmount)
                .build();

        Booking savedBooking = bookingRepository.save(booking);
        log.info("Booking created successfully with ID: {}", savedBooking.getId());

        // Step 5: Trigger payment
        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setBookingId(savedBooking.getId());
        paymentRequest.setGuestId(savedBooking.getGuestId());
        paymentRequest.setAmount(totalAmount);

        paymentServiceClient.generateBill(paymentRequest);

        return savedBooking;
    }

    @Override
    public BookingResponse createBookingWithDetails(Long guestId, BookingRequest request) {
        log.info("Creating booking with full details for guestId={}", guestId);
        Booking savedBooking = createBooking(guestId, request);

        Guest guest = guestServiceClient.getGuestById(savedBooking.getGuestId());

        Payment payment = paymentServiceClient.generateBill(new PaymentRequest(
                savedBooking.getId(), savedBooking.getGuestId(), savedBooking.getTotalAmount()
        ));

        return BookingResponse.builder()
                .bookingId(savedBooking.getId())
                .guestName(guest.getName())
                .guestEmail(guest.getEmail())
                .roomType(savedBooking.getRoomType())
                .roomPrice(savedBooking.getRoomPrice())
                .checkInDate(savedBooking.getCheckInDate())
                .checkOutDate(savedBooking.getCheckOutDate())
                .totalAmount(savedBooking.getTotalAmount())
                .paymentStatus(payment.getStatus())
                .build();
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    @Override
    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }

    @Override
    public List<Booking> getBookingsByGuestId(Long guestId) {
        return bookingRepository.findByGuestId(guestId);
    }
}
