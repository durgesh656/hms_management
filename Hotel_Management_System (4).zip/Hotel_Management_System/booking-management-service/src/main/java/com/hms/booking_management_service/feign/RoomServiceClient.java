package com.hms.booking_management_service.feign;

import com.hms.booking_management_service.dto.Room;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "room-management-service")
public interface RoomServiceClient {

    @GetMapping("/api/rooms/available/{roomType}")
    Room getAvailableRoomByType(@PathVariable("type") String type);

    @PutMapping("/api/rooms/{roomId}/availability")
    void updateRoomAvailability(
            @RequestHeader("X-Role") String role,
            @PathVariable("roomId") Long roomId,
            @RequestParam("available") boolean available);

}
