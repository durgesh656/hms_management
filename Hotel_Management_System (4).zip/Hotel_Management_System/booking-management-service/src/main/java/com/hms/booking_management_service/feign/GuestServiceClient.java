package com.hms.booking_management_service.feign;

import com.hms.booking_management_service.dto.Guest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "guest-management-service")
public interface GuestServiceClient {

    @GetMapping("/api/guests/{id}")
    Guest getGuestById(@PathVariable("id") Long id);
}
