package com.hms.booking_management_service.controller;

import com.hms.booking_management_service.dto.BookingRequest;
import com.hms.booking_management_service.dto.BookingResponse;
import com.hms.booking_management_service.entities.Booking;
import com.hms.booking_management_service.services.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    @PostMapping
    public ResponseEntity<?> createBooking(
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-Role") String role,
            @Valid @RequestBody BookingRequest request
    ) {
        log.info("Create booking request by userId={}, role={}", userId, role);

        try {
            BookingResponse response = bookingService.createBookingWithDetails(userId, request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body("Failed to create booking: " + e.getMessage());
        }
    }

    @PostMapping("/{guestId}")
    public ResponseEntity<BookingResponse> createBooking(
            @PathVariable Long guestId,
            @Valid @RequestBody BookingRequest request) {
        BookingResponse response = bookingService.createBookingWithDetails(guestId, request);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<?> getAllBookings(
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-Role") String role
    ) {
        log.info("Fetch all bookings requested by role: {}", role);
        List<Booking> bookings = "admin".equalsIgnoreCase(role)
                ? bookingService.getAllBookings()
                : bookingService.getBookingsByGuestId(userId);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getBookingById(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-Role") String role
    ) {
        return bookingService.getBookingById(id)
                .map(booking -> {
                    if (!"admin".equalsIgnoreCase(role) && !booking.getGuestId().equals(userId)) {
                        return ResponseEntity.status(403).body("Unauthorized access to this booking.");
                    }
                    return ResponseEntity.ok(booking);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/user")
    public ResponseEntity<List<Booking>> getBookingsByGuestId(@RequestHeader("X-User-Id") Long guestId,
                                                              @RequestHeader("X-Role") String role) {
        log.info("User with ID {} and role {} requested their bookings", guestId, role);

        // Ensure only users can access this endpoint
        if (!role.equalsIgnoreCase("user")) {
            return ResponseEntity.status(403).build(); // Forbidden
        }

        List<Booking> bookings = bookingService.getBookingsByGuestId(guestId);
        return ResponseEntity.ok(bookings);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBooking(
            @PathVariable Long id,
            @RequestHeader("X-Role") String role
    ) {
        if (!"admin".equalsIgnoreCase(role)) {
            return ResponseEntity.status(403).body("Only admin can delete bookings.");
        }

        bookingService.deleteBooking(id);
        return ResponseEntity.ok("Booking deleted with ID: " + id);
    }
}
