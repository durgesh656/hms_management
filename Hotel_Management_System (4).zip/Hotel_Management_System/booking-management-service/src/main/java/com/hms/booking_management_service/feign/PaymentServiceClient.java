package com.hms.booking_management_service.feign;

import com.hms.booking_management_service.dto.Payment;
import com.hms.booking_management_service.dto.PaymentRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "billing-payment-service")
public interface PaymentServiceClient {

    @PostMapping("/api/payments")
    Payment generateBill(@RequestBody PaymentRequest paymentRequest);
}
