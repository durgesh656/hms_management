package com.hms.booking_management_service.services;

import com.hms.booking_management_service.dto.BookingRequest;
import com.hms.booking_management_service.dto.BookingResponse;
import com.hms.booking_management_service.entities.Booking;

import java.util.List;
import java.util.Optional;

public interface BookingService {
    Booking createBooking(Long guestId, BookingRequest request);
    BookingResponse createBookingWithDetails( Long guestId, BookingRequest request);
    List<Booking> getAllBookings();
    Optional<Booking> getBookingById(Long id);
    void deleteBooking(Long id);
    List<Booking> getBookingsByGuestId(Long guestId);

}
