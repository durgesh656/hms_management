package com.hms.registration_service.feign;

import com.hms.registration_service.model.RoomDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "room-management-service")
public interface RoomClient {
    @GetMapping("/api/rooms")
    List<RoomDTO> getAllRooms();
}
