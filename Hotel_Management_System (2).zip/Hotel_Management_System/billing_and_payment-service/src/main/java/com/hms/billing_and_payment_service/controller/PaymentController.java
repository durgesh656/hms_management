package com.hms.billing_and_payment_service.controller;

import com.hms.billing_and_payment_service.entities.Payment;
import com.hms.billing_and_payment_service.services.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {
    private final PaymentService paymentService;

    @PostMapping
    public ResponseEntity<Payment> makePayment(@RequestBody Payment payment) {
        log.info("Received payment request: {}", payment);
        Payment processed = paymentService.makePayment(payment);
        log.info("Payment processed successfully: {}", processed);
        return ResponseEntity.ok(processed);    }

    @GetMapping
    public ResponseEntity<List<Payment>> getAllPayments() {
        log.info("Fetching all payments");
        List<Payment> payments = paymentService.getAllPayments();
        log.info("Total payments found: {}", payments.size());
        return ResponseEntity.ok(payments);    }

    @GetMapping("/{id}")
    public ResponseEntity<Payment> getPaymentById(@PathVariable Long id) {
        log.info("Fetching payment by ID: {}", id);
        return paymentService.getPaymentById(id)
                .map(payment -> {
                    log.info("Payment found: {}", payment);
                    return ResponseEntity.ok(payment);
                })
                .orElseGet(() -> {
                    log.warn("Payment with ID {} not found", id);
                    return ResponseEntity.notFound().build();
                });
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePayment(@PathVariable Long id) {
        log.info("Deleting payment with ID: {}", id);
        paymentService.deletePayment(id);
        log.info("Payment with ID {} deleted", id);
        return ResponseEntity.noContent().build();
    }
}
