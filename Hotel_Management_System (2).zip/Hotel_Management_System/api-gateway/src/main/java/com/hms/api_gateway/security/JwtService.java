package com.hms.api_gateway.security;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import java.security.Key;

@Service
public class JwtService {

    private static final String SECRET_KEY = "your-very-secret-key-your-very-secret-key"; // should be 256-bit length for HS256

    private final Key key = Keys.hmacShaKeyFor(SECRET_KEY.getBytes());

    private final JwtParser jwtParser = Jwts.parserBuilder()
            .setSigningKey(key)
            .build();

    public void validateToken(String token) {
        jwtParser.parseClaimsJws(token);  // throws exception if invalid
    }
}
