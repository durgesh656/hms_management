package com.hms.room_management_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RoomStatusResponse {
    private long totalRooms;
    private long bookedRooms;
    private long availableRooms;
}
