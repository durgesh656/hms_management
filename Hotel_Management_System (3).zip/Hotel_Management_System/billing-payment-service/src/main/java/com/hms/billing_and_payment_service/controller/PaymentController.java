package com.hms.billing_and_payment_service.controller;

import com.hms.billing_and_payment_service.entities.Payment;
import com.hms.billing_and_payment_service.services.PaymentService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {
    private final PaymentService paymentService;

    @PostMapping
    @Operation(summary = "Make a new payment")
    public ResponseEntity<Payment> makePayment(@Valid @RequestBody Payment payment) {
        log.info("Received payment request: {}", payment);
        Payment processed = paymentService.makePayment(payment);
        log.info("Payment processed successfully: {}", processed);
        return ResponseEntity.ok(processed);    }

    @GetMapping
    @Operation(summary = "Retrieve all payments")
    public ResponseEntity<List<Payment>> getAllPayments() {
        log.info("Fetching all payments");
        List<Payment> payments = paymentService.getAllPayments();
        log.info("Total payments found: {}", payments.size());
        return ResponseEntity.ok(payments);    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a payment by its ID")
    public ResponseEntity<Payment> getPaymentById(@PathVariable Long id) {
        log.info("Fetching payment by ID: {}", id);
        return paymentService.getPaymentById(id)
                .map(payment -> {
                    log.info("Payment found: {}", payment);
                    return ResponseEntity.ok(payment);
                })
                .orElseGet(() -> {
                    log.warn("Payment with ID {} not found", id);
                    return ResponseEntity.notFound().build();
                });
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a payment by its ID")
    public ResponseEntity<Void> deletePayment(@PathVariable Long id) {
        log.info("Deleting payment with ID: {}", id);
        paymentService.deletePayment(id);
        log.info("Payment with ID {} deleted", id);
        return ResponseEntity.noContent().build();
    }
}
