//package com.hms.api_gateway.config;
//
//import com.hms.api_gateway.security.JwtAuthFilter;
//import lombok.RequiredArgsConstructor;
//import org.springframework.cloud.gateway.route.RouteLocator;
//import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//@RequiredArgsConstructor
//public class GatewayConfig {
//
//    private final JwtAuthFilter jwtAuthFilter;
//
//    @Bean
//    public RouteLocator customRoutes(RouteLocatorBuilder builder) {
//        return builder.routes()
//
//                .route("registration-service", r -> r
//                        .path("/api/registration/**")
//                        .uri("http://localhost:8082"))
//
//                .route("room-service", r -> r
//                        .path("/api/rooms/**")
//                        .filters(f -> f.filter(jwtAuthFilter))
//                        .uri("http://localhost:8084"))
//
//                .route("booking-service", r -> r
//                        .path("/api/bookings/**")
//                        .filters(f -> f.filter(jwtAuthFilter))
//                        .uri("http://localhost:8085"))
//
//                .route("guest-service", r -> r
//                        .path("/api/guests/**")
//                        .filters(f -> f.filter(jwtAuthFilter))
//                        .uri("http://localhost:8083"))
//
//                .route("payment-service", r -> r
//                        .path("/api/payments/**")
//                        .filters(f -> f.filter(jwtAuthFilter))
//                        .uri("http://localhost:8086"))
//
//                .build();
//    }
//}
