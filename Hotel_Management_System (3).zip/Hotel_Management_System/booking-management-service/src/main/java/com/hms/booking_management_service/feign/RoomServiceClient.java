package com.hms.booking_management_service.feign;

import com.hms.booking_management_service.dto.Room;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "room-management-service")
public interface RoomServiceClient {

    @GetMapping("/api/rooms/available/{type}")
    Room getAvailableRoomByType(@PathVariable("type") String type);

    @PutMapping("/api/rooms/{id}/availability")
    void updateRoomAvailability(@PathVariable("id") Long id, @RequestParam("available") boolean available);

}
